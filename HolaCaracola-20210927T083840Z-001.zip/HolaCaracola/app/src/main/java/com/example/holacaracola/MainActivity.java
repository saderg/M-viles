package com.example.holacaracola;

import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {


    public static final String EXTRA_MESSAGE = "com.example.holacaracola.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void enviar(View view){
        TextInputEditText texto = (TextInputEditText) findViewById(R.id.texto);
        String nombre = texto.getText().toString();
        Intent intent = new Intent(this, QuePacha.class);
        intent.putExtra(EXTRA_MESSAGE, nombre);
        startActivity(intent);
    }
}